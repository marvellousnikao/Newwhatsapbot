#!/bin/bash
echo "Updating packages..."
pkg update -y && pkg upgrade -y

echo "Installing dependencies..."
pkg install nodejs git ffmpeg imagemagick -y

echo "Cloning the repository..."
git clone https://github.com/your-username/custom-whatsapp-bot.git
cd custom-whatsapp-bot

echo "Installing Node.js dependencies..."
npm install

echo "Starting the bot..."
node index.js
