//base by 𝕶𝖎𝖓𝖌 𝕾𝖆𝖒)

 exports.noToken = "The bot token cannot be empty, please create a bot via https://t.me/BotFather"

exports.first_chat = (botname, pushname) => {
    return `Hi bro ${pushname} am SPIDER-X, a bot that can destroy whatsapp user\nClick /menu to learn more about how to use this bot

[Subscribe YouTube Channel](https://youtube.com/@king_sam_hub?si=GugMiOj7kMAdDQ5q)
[Join Telegram Channel](https://t.me/KingSamHub)
[Join WhatsApp Channel](https://whatsapp.com/channel/0029VaaqaSp0LKZDuwe5SI3e)
[Follow Instagram](https://youtube.com/@king_sam_hub?si=GugMiOj7kMAdDQ5q)
[Follow GitHub](https://youtube.com/@king_sam_hub?si=GugMiOj7kMAdDQ5q)`;
};